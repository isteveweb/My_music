package com.example.musictestagain.utilities

import com.example.musictestagain.data.model.Music

const val SHARED_PREFERENCES_NAME = "MySharedPreferences"
const val IS_THE_FIRST_TIME = "first_time_open_the_app"

val MusicItemWithInitialValue =
    Music("", "", 0, "", "", "", "", "", "", 0, 0)


