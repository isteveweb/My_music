package com.example.musictestagain.data.model

data class MusicResponse(
    val music: List<Music>
)