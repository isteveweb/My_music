package com.example.musictestagain.ui.base

import androidx.lifecycle.ViewModel

abstract class BaseViewModel : ViewModel() {
}